package com.abcsecurity.counterdrone;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.PreparedStatement;
import java.sql.Statement;

/** Rule-based DEMO scoring. This is not a real AI model and uses no real sensor data. */
@Service
public class SimulationService {
    private final JdbcTemplate jdbc;

    public SimulationService(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    public record Result(long detectionId, String level, double risk, String action, boolean incidentCreated) {}

    @Transactional
    public Result run(String drone, int sensorId, int zoneId, double lat, double lon,
                      double alt, double spd, String dir, double sig) {
        if (drone == null || drone.isBlank()) throw new IllegalArgumentException("Drone ID is required.");
        if (lat < -90 || lat > 90 || lon < -180 || lon > 180 || alt < 0 || spd < 0)
            throw new IllegalArgumentException("Coordinates or telemetry values are outside valid ranges.");

        String level = (spd > 80 || alt < 20 || sig > -25) ? "HIGH" : (spd > 50 ? "MEDIUM" : "LOW");
        double risk = level.equals("HIGH") ? 85 : level.equals("MEDIUM") ? 55 : 20;
        String action = level.equals("HIGH") ? "Verify visually and notify command center"
                : level.equals("MEDIUM") ? "Continue observation and verify identity" : "Continue routine monitoring";

        long detId = insert("INSERT INTO drone_detections(drone_id,sensor_id,zone_id,gps_latitude,gps_longitude,altitude_m,speed_kmh,direction,signal_strength) VALUES(?,?,?,?,?,?,?,?,?)",
                drone, sensorId, zoneId, lat, lon, alt, spd, dir, sig);
        jdbc.update("INSERT INTO drone_tracking(drone_id,detection_id,gps_latitude,gps_longitude,altitude_m,speed_kmh,direction) VALUES(?,?,?,?,?,?,?)",
                drone, detId, lat, lon, alt, spd, dir);
        long classId = insert("INSERT INTO ai_threat_classification(detection_id,threat_level,movement_pattern,risk_score,restricted_zone_proximity_m,recommended_action,model_label) VALUES(?,?,?,?,?,?,?)",
                detId, level, spd > 50 ? "FAST_MOVEMENT" : "ROUTINE_MOVEMENT", risk, 500, action, "RULE_BASED_DEMO_V1");

        boolean incident = level.equals("HIGH");
        if (incident) {
            long incId = insert("INSERT INTO incidents(detection_id,zone_id,classification_id,incident_time,response_status) VALUES(?,?,?,NOW(),'OPEN')",
                    detId, zoneId, classId);
            jdbc.update("INSERT INTO alerts(incident_id,alert_type,severity,recipient_group,status,message) VALUES(?,?,?,?,?,?)",
                    incId, "HIGH_RISK_DRONE", "HIGH", "Command Center", "NEW", "Simulated high-risk detection for " + drone);
        }
        return new Result(detId, level, risk, action, incident);
    }

    private long insert(String sql, Object... args) {
        KeyHolder kh = new GeneratedKeyHolder();
        jdbc.update(con -> {
            PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            for (int i = 0; i < args.length; i++) ps.setObject(i + 1, args[i]);
            return ps;
        }, kh);
        return kh.getKey().longValue();
    }
}
