package com.abcsecurity.counterdrone;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.*;

@Controller
public class AppController {
    private final JdbcTemplate jdbc;
    private final SimulationService simulation;
    private final PasswordEncoder encoder;
    @Value("${app.demo-mode}") private boolean demo;

    public AppController(JdbcTemplate jdbc, SimulationService simulation, PasswordEncoder encoder) {
        this.jdbc = jdbc; this.simulation = simulation; this.encoder = encoder;
    }

    // ---------------------------------------------------------- helpers
    private static boolean has(Authentication a, String role) {
        return a != null && a.getAuthorities().stream().anyMatch(g -> g.getAuthority().equals("ROLE_" + role));
    }
    private static boolean isAdmin(Authentication a) { return has(a, "ADMIN"); }
    private static boolean isOperator(Authentication a) { return has(a, "OPERATOR"); }

    private static boolean canWrite(TableSpec s, Authentication a) {
        return switch (s.access()) {
            case READ_ONLY -> false;
            case ADMIN_ONLY -> isAdmin(a);
            default -> isAdmin(a) || isOperator(a);
        };
    }
    private static boolean canDelete(TableSpec s, Authentication a) {
        return s.access() != Access.READ_ONLY && isAdmin(a);
    }
    private static TableSpec spec(String key) {
        TableSpec s = TableSpec.ALL.get(key);
        if (s == null) throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        return s;
    }
    private void audit(Authentication a, String action, String entity, String id, String details) {
        try {
            jdbc.update("INSERT INTO audit_log(username,action_name,entity_name,entity_id,details) VALUES(?,?,?,?,?)",
                    a.getName(), action, entity, id, details);
        } catch (DataAccessException e) { System.err.println("Audit write failed: " + e.getMessage()); }
    }
    private int count(String sql) {
        try { Integer n = jdbc.queryForObject(sql, Integer.class); return n == null ? 0 : n; }
        catch (DataAccessException e) { return 0; }
    }

    @ModelAttribute
    void common(Model m, Authentication a) {
        if (a == null) return;
        m.addAttribute("username", a.getName());
        m.addAttribute("role", isAdmin(a) ? "Administrator" : isOperator(a) ? "Operator" : "Viewer");
        m.addAttribute("specs", TableSpec.ALL.values());
        m.addAttribute("canSimulate", isAdmin(a) || isOperator(a));
    }

    // ---------------------------------------------------------- pages
    @GetMapping("/login")
    String login(Model m) { m.addAttribute("demo", demo); return "login"; }

    @GetMapping("/")
    String home(Model m) {
        Map<String, Integer> metrics = new LinkedHashMap<>();
        metrics.put("Surveillance zones", count("SELECT COUNT(*) FROM surveillance_zones"));
        metrics.put("Sensor stations", count("SELECT COUNT(*) FROM sensor_stations"));
        metrics.put("Drone detections", count("SELECT COUNT(*) FROM drone_detections"));
        metrics.put("Open incidents", count("SELECT COUNT(*) FROM incidents WHERE response_status <> 'CLOSED'"));
        metrics.put("Unacknowledged alerts", count("SELECT COUNT(*) FROM alerts WHERE status <> 'ACKNOWLEDGED'"));
        metrics.put("Response teams", count("SELECT COUNT(*) FROM response_teams"));
        m.addAttribute("metrics", metrics);
        return "dashboard";
    }

    @GetMapping("/t/{key}")
    String list(@PathVariable String key, @RequestParam(required = false) Long edit, Model m, Authentication a) {
        TableSpec s = spec(key);
        List<Map<String, Object>> rows = jdbc.queryForList("SELECT " + String.join(",", s.selectColumns())
                + " FROM " + s.table() + " ORDER BY " + s.id() + " DESC LIMIT 500");
        Map<String, Object> editRow = new HashMap<>();
        Long editId = null;
        if (edit != null) {
            for (Map<String, Object> r : rows) {
                Object idVal = r.get(s.id());
                if (idVal instanceof Number n && n.longValue() == edit) { editRow = r; editId = edit; break; }
            }
        }
        m.addAttribute("spec", s);
        m.addAttribute("rows", rows);
        m.addAttribute("editRow", editRow);
        m.addAttribute("editId", editId);
        m.addAttribute("canWrite", canWrite(s, a));
        m.addAttribute("canDelete", canDelete(s, a));
        return "table";
    }

    @PostMapping("/t/{key}/add")
    String add(@PathVariable String key, @RequestParam Map<String, String> p, Authentication a, RedirectAttributes ra) {
        TableSpec s = spec(key);
        if (!canWrite(s, a)) throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        List<String> cols = new ArrayList<>();
        List<Object> vals = new ArrayList<>();
        for (String c : s.columns()) {
            String v = p.get(c);
            if (v != null && !v.isBlank()) { cols.add(c); vals.add(v.trim()); }
        }
        if (cols.isEmpty()) { ra.addFlashAttribute("error", "Enter at least one value."); return "redirect:/t/" + key; }
        try {
            jdbc.update("INSERT INTO " + s.table() + "(" + String.join(",", cols) + ") VALUES(" + "?,".repeat(cols.size() - 1) + "?)", vals.toArray());
            audit(a, "INSERT", s.table(), "", "Record inserted");
            ra.addFlashAttribute("message", "Record added.");
        } catch (DataAccessException e) {
            ra.addFlashAttribute("error", "Could not save. Check that values are valid and referenced records exist.");
        }
        return "redirect:/t/" + key;
    }

    @PostMapping("/t/{key}/update/{id}")
    String update(@PathVariable String key, @PathVariable long id, @RequestParam Map<String, String> p,
                  Authentication a, RedirectAttributes ra) {
        TableSpec s = spec(key);
        if (!canWrite(s, a)) throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        List<String> sets = new ArrayList<>();
        List<Object> vals = new ArrayList<>();
        for (String c : s.columns()) {
            String v = p.get(c);
            if (v != null && !v.isBlank()) { sets.add(c + "=?"); vals.add(v.trim()); }
        }
        if (sets.isEmpty()) { ra.addFlashAttribute("error", "Nothing to update."); return "redirect:/t/" + key; }
        vals.add(id);
        try {
            jdbc.update("UPDATE " + s.table() + " SET " + String.join(",", sets) + " WHERE " + s.id() + "=?", vals.toArray());
            audit(a, "UPDATE", s.table(), String.valueOf(id), "Record updated");
            ra.addFlashAttribute("message", "Record updated.");
        } catch (DataAccessException e) {
            ra.addFlashAttribute("error", "Could not update. Check that values are valid and referenced records exist.");
        }
        return "redirect:/t/" + key;
    }

    @PostMapping("/t/{key}/delete/{id}")
    String delete(@PathVariable String key, @PathVariable long id, Authentication a, RedirectAttributes ra) {
        TableSpec s = spec(key);
        if (!canDelete(s, a)) throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        try {
            jdbc.update("DELETE FROM " + s.table() + " WHERE " + s.id() + "=?", id);
            audit(a, "DELETE", s.table(), String.valueOf(id), "Record deleted");
            ra.addFlashAttribute("message", "Record deleted.");
        } catch (DataAccessException e) {
            ra.addFlashAttribute("error", "Could not delete. Other records may still refer to it.");
        }
        return "redirect:/t/" + key;
    }

    @PostMapping("/users/password")
    String setPassword(@RequestParam long userId, @RequestParam String password, Authentication a, RedirectAttributes ra) {
        if (!isAdmin(a)) throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        if (password == null || password.length() < 8) {
            ra.addFlashAttribute("error", "Password must be at least 8 characters.");
        } else if (jdbc.update("UPDATE app_users SET password_hash=? WHERE user_id=?", encoder.encode(password), userId) == 0) {
            ra.addFlashAttribute("error", "No user with that ID.");
        } else {
            audit(a, "SET_PASSWORD", "app_users", String.valueOf(userId), "Password changed");
            ra.addFlashAttribute("message", "Password updated.");
        }
        return "redirect:/t/users";
    }

    // ---------------------------------------------------------- simulation
    @GetMapping("/simulate")
    String simulateForm(Model m, Authentication a) {
        if (!(isAdmin(a) || isOperator(a))) throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        m.addAttribute("sensors", jdbc.queryForList("SELECT sensor_id AS id, sensor_name AS name FROM sensor_stations ORDER BY sensor_id"));
        m.addAttribute("zones", jdbc.queryForList("SELECT zone_id AS id, zone_name AS name FROM surveillance_zones ORDER BY zone_id"));
        return "simulate";
    }

    @PostMapping("/simulate")
    String simulateRun(@RequestParam String drone, @RequestParam String lat, @RequestParam String lon,
                       @RequestParam String alt, @RequestParam String speed, @RequestParam String dir,
                       @RequestParam String signal, @RequestParam(required = false) String sensor,
                       @RequestParam(required = false) String zone, Authentication a, RedirectAttributes ra) {
        if (!(isAdmin(a) || isOperator(a))) throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        try {
            if (sensor == null || zone == null || sensor.isBlank() || zone.isBlank())
                throw new IllegalArgumentException("Add a sensor and a zone first.");
            SimulationService.Result r = simulation.run(drone.trim(), Integer.parseInt(sensor), Integer.parseInt(zone),
                    Double.parseDouble(lat), Double.parseDouble(lon), Double.parseDouble(alt),
                    Double.parseDouble(speed), dir.trim(), Double.parseDouble(signal));
            audit(a, "SIMULATED_DETECTION", "drone_detections", String.valueOf(r.detectionId()), "Rule-based demo scoring");
            ra.addFlashAttribute("result", "SIMULATION ONLY. No real sensor data was received.\nDetection ID: " + r.detectionId()
                    + "\nThreat level: " + r.level() + "  |  Risk score: " + r.risk() + "/100\nRecommended action: " + r.action()
                    + (r.incidentCreated() ? "\nAn incident and an alert were created." : ""));
        } catch (NumberFormatException e) {
            ra.addFlashAttribute("error", "Latitude, longitude, altitude, speed and signal must be numbers.");
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("error", e.getMessage());
        } catch (DataAccessException e) {
            ra.addFlashAttribute("error", "The simulation could not be saved. Check the database.");
        }
        return "redirect:/simulate";
    }
}
