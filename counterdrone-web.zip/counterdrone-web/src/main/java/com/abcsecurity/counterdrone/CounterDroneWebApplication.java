package com.abcsecurity.counterdrone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/** Educational counter-drone console. Detections and threat scores are SIMULATED. */
@SpringBootApplication
public class CounterDroneWebApplication {
    public static void main(String[] args) {
        SpringApplication.run(CounterDroneWebApplication.class, args);
    }
}
