package com.abcsecurity.counterdrone;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/** Seeds BCrypt-hashed demo accounts on first start (only when app_users is empty and DEMO_MODE=true). */
@Component
public class DataInitializer implements CommandLineRunner {
    private final JdbcTemplate jdbc;
    private final PasswordEncoder encoder;
    @Value("${app.demo-mode}") private boolean demo;

    public DataInitializer(JdbcTemplate jdbc, PasswordEncoder encoder) { this.jdbc = jdbc; this.encoder = encoder; }

    @Override
    public void run(String... args) {
        Integer n = jdbc.queryForObject("SELECT COUNT(*) FROM app_users", Integer.class);
        if (n == null || n > 0) return;
        if (!demo) {
            System.out.println("No users exist and DEMO_MODE=false. Insert an administrator manually.");
            return;
        }
        create("admin", "System Administrator", "Administrator", "Admin@123");
        create("operator", "Demo Operator", "Operator", "Operator@123");
        create("viewer", "Demo Viewer", "Viewer", "Viewer@123");
        System.out.println("Demo users created: admin, operator, viewer.");
    }

    private void create(String user, String name, String role, String password) {
        jdbc.update("INSERT INTO app_users(username,full_name,role_name,email,account_status,password_hash) VALUES(?,?,?,?,?,?)",
                user, name, role, user + "@example.com", "ACTIVE", encoder.encode(password));
    }
}
