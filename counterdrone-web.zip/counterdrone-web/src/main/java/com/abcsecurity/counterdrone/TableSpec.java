package com.abcsecurity.counterdrone;

import java.util.*;

/** Whitelist of tables the generic CRUD pages may touch. Names never come from user input. */
public record TableSpec(String key, String label, String table, String id, Access access, List<String> columns) {

    public static final Map<String, TableSpec> ALL = new LinkedHashMap<>();

    private static void add(String key, String label, String table, String id, Access access, String... cols) {
        ALL.put(key, new TableSpec(key, label, table, id, access, List.of(cols)));
    }

    static {
        add("zones", "Surveillance Zones", "surveillance_zones", "zone_id", Access.NORMAL,
            "zone_name", "zone_type", "gps_latitude", "gps_longitude", "security_level", "monitoring_status");
        add("sensors", "Sensor Stations", "sensor_stations", "sensor_id", Access.NORMAL,
            "sensor_name", "sensor_type", "location", "operational_status", "coverage_radius_km", "zone_id");
        add("detections", "Drone Detections", "drone_detections", "detection_id", Access.NORMAL,
            "drone_id", "detection_time", "sensor_id", "zone_id", "gps_latitude", "gps_longitude",
            "altitude_m", "speed_kmh", "direction", "signal_strength");
        add("tracking", "Drone Tracking", "drone_tracking", "tracking_id", Access.NORMAL,
            "drone_id", "detection_id", "tracked_at", "gps_latitude", "gps_longitude", "altitude_m", "speed_kmh", "direction");
        add("classification", "AI Threat Classification", "ai_threat_classification", "classification_id", Access.NORMAL,
            "detection_id", "threat_level", "movement_pattern", "risk_score", "restricted_zone_proximity_m", "recommended_action", "model_label");
        add("incidents", "Incidents", "incidents", "incident_id", Access.NORMAL,
            "detection_id", "zone_id", "classification_id", "incident_time", "response_status", "assigned_team_id", "resolution");
        add("teams", "Response Teams", "response_teams", "team_id", Access.NORMAL,
            "team_name", "team_leader", "equipment", "availability_status");
        add("actions", "Response Actions", "response_actions", "action_id", Access.NORMAL,
            "incident_id", "team_id", "deployment_time", "action_taken", "closure_time", "notes");
        add("alerts", "Alerts", "alerts", "alert_id", Access.NORMAL,
            "incident_id", "alert_type", "severity", "recipient_group", "alert_time", "status", "message");
        add("reports", "Reports", "reports", "report_id", Access.NORMAL,
            "report_type", "generated_by", "generated_at", "period_start", "period_end", "file_reference");
        add("dashboard", "Command Dashboard", "command_dashboard", "dashboard_id", Access.NORMAL,
            "dashboard_name", "owner_user_id", "layout_json", "last_updated");
        add("users", "Users", "app_users", "user_id", Access.ADMIN_ONLY,
            "username", "full_name", "role_name", "email", "account_status");
        add("login-log", "Login Log", "login_log", "login_log_id", Access.READ_ONLY,
            "username", "login_time", "result", "source_note");
        add("audit", "Audit Log", "audit_log", "audit_id", Access.READ_ONLY,
            "username", "event_time", "action_name", "entity_name", "entity_id", "details");
        add("settings", "System Settings", "system_settings", "setting_id", Access.ADMIN_ONLY,
            "setting_key", "setting_value", "description");
        add("security-events", "Security Events", "security_events", "security_event_id", Access.NORMAL,
            "event_type", "event_time", "severity", "zone_id", "description", "status");
    }

    /** id column followed by editable columns, for SELECT lists. */
    public List<String> selectColumns() {
        List<String> all = new ArrayList<>();
        all.add(id);
        all.addAll(columns);
        return all;
    }
}
