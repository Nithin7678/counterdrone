package com.abcsecurity.counterdrone;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

import java.util.List;
import java.util.Map;

@Configuration
public class SecurityConfig {

    @Bean
    PasswordEncoder passwordEncoder() { return new BCryptPasswordEncoder(); }

    @Bean
    SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.authorizeHttpRequests(a -> a
                        .requestMatchers("/login", "/style.css").permitAll()
                        .anyRequest().authenticated())
                .formLogin(f -> f.loginPage("/login").defaultSuccessUrl("/", true).permitAll())
                .logout(l -> l.logoutSuccessUrl("/login?logout"));
        return http.build(); // CSRF protection stays on (Thymeleaf adds the token to forms)
    }

    @Bean
    UserDetailsService userDetailsService(JdbcTemplate jdbc, LoginAttempts attempts) {
        return username -> {
            List<Map<String, Object>> rows = jdbc.queryForList(
                    "SELECT username, password_hash, role_name FROM app_users WHERE username=? AND account_status='ACTIVE'", username);
            if (rows.isEmpty()) throw new UsernameNotFoundException("Unknown user");
            Map<String, Object> row = rows.get(0);
            String roleName = String.valueOf(row.get("role_name"));
            String role = switch (roleName) {
                case "Administrator" -> "ADMIN";
                case "Operator" -> "OPERATOR";
                default -> "VIEWER";
            };
            return User.withUsername(String.valueOf(row.get("username")))
                    .password(String.valueOf(row.get("password_hash")))
                    .roles(role)
                    .accountLocked(attempts.isLocked(username))
                    .build();
        };
    }
}
