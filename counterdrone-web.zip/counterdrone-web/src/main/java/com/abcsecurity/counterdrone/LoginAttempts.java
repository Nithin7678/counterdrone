package com.abcsecurity.counterdrone;

import org.springframework.context.event.EventListener;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.authentication.event.AuthenticationFailureBadCredentialsEvent;
import org.springframework.security.authentication.event.AuthenticationSuccessEvent;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Locks an account for 5 minutes after 5 failed sign-ins and records every attempt in login_log. */
@Component
public class LoginAttempts {
    private static final int MAX_FAILS = 5;
    private static final long LOCK_MS = 5 * 60 * 1000L;
    private final Map<String, Integer> counts = new ConcurrentHashMap<>();
    private final Map<String, Long> lockedUntil = new ConcurrentHashMap<>();
    private final JdbcTemplate jdbc;

    public LoginAttempts(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    public boolean isLocked(String user) {
        Long until = lockedUntil.get(user);
        if (until == null) return false;
        if (until < System.currentTimeMillis()) { lockedUntil.remove(user); counts.remove(user); return false; }
        return true;
    }

    @EventListener
    public void failed(AuthenticationFailureBadCredentialsEvent e) {
        String user = e.getAuthentication().getName();
        int n = counts.merge(user, 1, Integer::sum);
        if (n >= MAX_FAILS) lockedUntil.put(user, System.currentTimeMillis() + LOCK_MS);
        log(user, "FAILED");
    }

    @EventListener
    public void succeeded(AuthenticationSuccessEvent e) {
        String user = e.getAuthentication().getName();
        counts.remove(user); lockedUntil.remove(user);
        log(user, "SUCCESS");
    }

    private void log(String user, String result) {
        try {
            jdbc.update("INSERT INTO login_log(username,result,source_note) VALUES(?,?,?)", user, result, "Web application");
        } catch (Exception ex) { System.err.println("Login log failed: " + ex.getMessage()); }
    }
}
