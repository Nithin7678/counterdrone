package com.abcsecurity.counterdrone;

public enum Access { NORMAL, ADMIN_ONLY, READ_ONLY }
