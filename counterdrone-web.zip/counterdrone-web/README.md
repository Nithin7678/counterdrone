# Counter-Drone Command Console (Spring Boot web version)

Educational prototype. Detections and threat scores are SIMULATED with simple rules.
It does not connect to any radar, RF, camera, GPS or defence system.

## Requirements
- JDK 17+
- Maven 3.8+ (or use an IDE such as IntelliJ, which bundles Maven)
- MySQL 8

## Run
1. Create the database:  `mysql -u root -p < database/schema.sql`
2. (Optional) set environment variables if your MySQL is not root with an empty password:
   `DB_URL`, `DB_USER`, `DB_PASSWORD`
   (Windows PowerShell: `$env:DB_PASSWORD="yourpass"`; macOS/Linux: `export DB_PASSWORD=yourpass`)
3. Start:  `mvn spring-boot:run`
4. Open http://localhost:8080

On first start with DEMO_MODE=true (default) the app creates BCrypt-hashed demo users:

| Username | Password | Role |
|---|---|---|
| admin | Admin@123 | Administrator |
| operator | Operator@123 | Operator |
| viewer | Viewer@123 | Viewer |

## Roles
- Administrator: add / update / delete everywhere, manage users and passwords
- Operator: add / update on operational tables, run simulations, no deletes
- Viewer: read only
- Login Log and Audit Log are read-only for everyone.

## Before any real deployment
Set DEMO_MODE=false, create your own admin user, use a dedicated MySQL user (not root), serve over HTTPS,
and review the code first. This is a learning project, not a hardened product.
