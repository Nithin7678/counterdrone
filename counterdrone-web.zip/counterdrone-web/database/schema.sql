-- Counter-Drone Threat Management (educational simulation) schema
-- Usage: mysql -u root -p < schema.sql

CREATE DATABASE IF NOT EXISTS counter_drone_db CHARACTER SET utf8mb4;
USE counter_drone_db;

CREATE TABLE surveillance_zones (
  zone_id INT AUTO_INCREMENT PRIMARY KEY,
  zone_name VARCHAR(100) NOT NULL,
  zone_type VARCHAR(50),
  gps_latitude DECIMAL(9,6),
  gps_longitude DECIMAL(9,6),
  security_level VARCHAR(20) DEFAULT 'MEDIUM',
  monitoring_status VARCHAR(20) DEFAULT 'ACTIVE'
);

CREATE TABLE sensor_stations (
  sensor_id INT AUTO_INCREMENT PRIMARY KEY,
  sensor_name VARCHAR(100) NOT NULL,
  sensor_type VARCHAR(50),
  location VARCHAR(150),
  operational_status VARCHAR(20) DEFAULT 'ONLINE',
  coverage_radius_km DECIMAL(6,2),
  zone_id INT,
  FOREIGN KEY (zone_id) REFERENCES surveillance_zones(zone_id)
);

CREATE TABLE response_teams (
  team_id INT AUTO_INCREMENT PRIMARY KEY,
  team_name VARCHAR(100) NOT NULL,
  team_leader VARCHAR(100),
  equipment VARCHAR(255),
  availability_status VARCHAR(20) DEFAULT 'AVAILABLE'
);

CREATE TABLE drone_detections (
  detection_id INT AUTO_INCREMENT PRIMARY KEY,
  drone_id VARCHAR(50) NOT NULL,
  detection_time DATETIME DEFAULT CURRENT_TIMESTAMP,
  sensor_id INT,
  zone_id INT,
  gps_latitude DECIMAL(9,6),
  gps_longitude DECIMAL(9,6),
  altitude_m DECIMAL(8,2),
  speed_kmh DECIMAL(8,2),
  direction VARCHAR(20),
  signal_strength DECIMAL(6,2),
  FOREIGN KEY (sensor_id) REFERENCES sensor_stations(sensor_id),
  FOREIGN KEY (zone_id) REFERENCES surveillance_zones(zone_id)
);

CREATE TABLE drone_tracking (
  tracking_id INT AUTO_INCREMENT PRIMARY KEY,
  drone_id VARCHAR(50) NOT NULL,
  detection_id INT,
  tracked_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  gps_latitude DECIMAL(9,6),
  gps_longitude DECIMAL(9,6),
  altitude_m DECIMAL(8,2),
  speed_kmh DECIMAL(8,2),
  direction VARCHAR(20),
  FOREIGN KEY (detection_id) REFERENCES drone_detections(detection_id)
);

CREATE TABLE ai_threat_classification (
  classification_id INT AUTO_INCREMENT PRIMARY KEY,
  detection_id INT NOT NULL,
  threat_level VARCHAR(20),
  movement_pattern VARCHAR(50),
  risk_score DECIMAL(5,2),
  restricted_zone_proximity_m INT,
  recommended_action VARCHAR(255),
  model_label VARCHAR(50),
  FOREIGN KEY (detection_id) REFERENCES drone_detections(detection_id)
);

CREATE TABLE incidents (
  incident_id INT AUTO_INCREMENT PRIMARY KEY,
  detection_id INT,
  zone_id INT,
  classification_id INT,
  incident_time DATETIME DEFAULT CURRENT_TIMESTAMP,
  response_status VARCHAR(20) DEFAULT 'OPEN',
  assigned_team_id INT,
  resolution TEXT,
  FOREIGN KEY (detection_id) REFERENCES drone_detections(detection_id),
  FOREIGN KEY (zone_id) REFERENCES surveillance_zones(zone_id),
  FOREIGN KEY (classification_id) REFERENCES ai_threat_classification(classification_id),
  FOREIGN KEY (assigned_team_id) REFERENCES response_teams(team_id)
);

CREATE TABLE response_actions (
  action_id INT AUTO_INCREMENT PRIMARY KEY,
  incident_id INT,
  team_id INT,
  deployment_time DATETIME DEFAULT CURRENT_TIMESTAMP,
  action_taken VARCHAR(255),
  closure_time DATETIME NULL,
  notes TEXT,
  FOREIGN KEY (incident_id) REFERENCES incidents(incident_id),
  FOREIGN KEY (team_id) REFERENCES response_teams(team_id)
);

CREATE TABLE alerts (
  alert_id INT AUTO_INCREMENT PRIMARY KEY,
  incident_id INT,
  alert_type VARCHAR(50),
  severity VARCHAR(20),
  recipient_group VARCHAR(100),
  alert_time DATETIME DEFAULT CURRENT_TIMESTAMP,
  status VARCHAR(20) DEFAULT 'NEW',
  message TEXT,
  FOREIGN KEY (incident_id) REFERENCES incidents(incident_id)
);

CREATE TABLE app_users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  full_name VARCHAR(100),
  role_name VARCHAR(30) NOT NULL DEFAULT 'Viewer',
  email VARCHAR(120),
  account_status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
  password_hash VARCHAR(100) NOT NULL DEFAULT ''
);

CREATE TABLE reports (
  report_id INT AUTO_INCREMENT PRIMARY KEY,
  report_type VARCHAR(50),
  generated_by VARCHAR(50),
  generated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  period_start DATE,
  period_end DATE,
  file_reference VARCHAR(255)
);

CREATE TABLE command_dashboard (
  dashboard_id INT AUTO_INCREMENT PRIMARY KEY,
  dashboard_name VARCHAR(100),
  owner_user_id INT,
  layout_json TEXT,
  last_updated DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (owner_user_id) REFERENCES app_users(user_id)
);

CREATE TABLE login_log (
  login_log_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50),
  login_time DATETIME DEFAULT CURRENT_TIMESTAMP,
  result VARCHAR(20),
  source_note VARCHAR(100)
);

CREATE TABLE audit_log (
  audit_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50),
  event_time DATETIME DEFAULT CURRENT_TIMESTAMP,
  action_name VARCHAR(50),
  entity_name VARCHAR(50),
  entity_id VARCHAR(50),
  details VARCHAR(255)
);

CREATE TABLE system_settings (
  setting_id INT AUTO_INCREMENT PRIMARY KEY,
  setting_key VARCHAR(100) NOT NULL UNIQUE,
  setting_value VARCHAR(255),
  description VARCHAR(255)
);

CREATE TABLE security_events (
  security_event_id INT AUTO_INCREMENT PRIMARY KEY,
  event_type VARCHAR(50),
  event_time DATETIME DEFAULT CURRENT_TIMESTAMP,
  severity VARCHAR(20),
  zone_id INT,
  description VARCHAR(255),
  status VARCHAR(20) DEFAULT 'OPEN',
  FOREIGN KEY (zone_id) REFERENCES surveillance_zones(zone_id)
);

-- ---------------------------------------------------------------- seed data
-- Users are created by the web app on first start (BCrypt) when DEMO_MODE=true.

INSERT INTO surveillance_zones (zone_name, zone_type, gps_latitude, gps_longitude, security_level, monitoring_status) VALUES
 ('Main Campus',        'Facility', 12.971600, 77.594600, 'HIGH',   'ACTIVE'),
 ('Perimeter North',    'Perimeter', 12.980000, 77.600000, 'MEDIUM', 'ACTIVE'),
 ('Restricted Airspace','No-fly',   12.960000, 77.585000, 'HIGH',   'ACTIVE');

INSERT INTO sensor_stations (sensor_name, sensor_type, location, operational_status, coverage_radius_km, zone_id) VALUES
 ('Sim Sensor A', 'SIMULATED', 'Rooftop A', 'ONLINE', 3.00, 1),
 ('Sim Sensor B', 'SIMULATED', 'North Gate', 'ONLINE', 2.50, 2);

INSERT INTO response_teams (team_name, team_leader, equipment, availability_status) VALUES
 ('Alpha Team', 'Demo Leader 1', 'Radios, observation kit', 'AVAILABLE'),
 ('Bravo Team', 'Demo Leader 2', 'Radios, observation kit', 'AVAILABLE');

INSERT INTO system_settings (setting_key, setting_value, description) VALUES
 ('SIMULATION_MODE', 'true', 'All detections are simulated'),
 ('HIGH_SPEED_THRESHOLD_KMH', '80', 'Rule-based demo threshold');
